function dragData()
{
    var sval=document.getElementById("mrange").value;
    document.getElementById("hval").value=sval;
}

var rangesl= document.getElementById("sliderRange1");
var output = document.getElementById("demo");
output.innerHTML = rangesl.value;
rangeslider.oninput = function() {
  output.innerHTML = this.value;
}