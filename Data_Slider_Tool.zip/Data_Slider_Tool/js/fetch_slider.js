 function currentData()
{
    var sval=document.getElementById("rang_id").value;
    document.getElementById("label_value").value=sval;
}